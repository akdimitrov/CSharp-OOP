﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T06.FoodShortage.Contracts
{
    public interface IBirthable
    {
        string Birthdate { get; set; }
    }
}
