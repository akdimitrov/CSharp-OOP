﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T06.FoodShortage.Contracts
{
    public interface IIdentifiable
    {
        string Id { get; set; }
    }
}
