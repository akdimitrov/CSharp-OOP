﻿using System;
using T09.ExplicitInterfaces.Core;

namespace T09.ExplicitInterfaces
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
