﻿using T08.CollectionHierarchy.Core;

namespace T08.CollectionHierarchy
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
