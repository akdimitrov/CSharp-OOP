﻿namespace T07.MilitaryElite.Contracts
{
    public interface ISpecialisedSoldier : IPrivate
    {
        string Corps { get; }
    }
}
