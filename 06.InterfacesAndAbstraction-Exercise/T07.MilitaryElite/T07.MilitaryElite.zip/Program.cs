﻿using T07.MilitaryElite.Core;

namespace T07.MilitaryElite
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }   
    }
}
