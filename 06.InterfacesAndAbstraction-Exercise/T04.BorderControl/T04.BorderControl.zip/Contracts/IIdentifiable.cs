﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T04.BorderControl.Contracts
{
    public interface IIdentifiable
    {
        string Id { get; set; }
    }
}
