﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T03.Telephony.Exceptions
{
    public static class ExceptionMessages
    {
        public static string InvalidNumberException = "Invalid number!";
        public static string InvalidUrlException = "Invalid URL!";
    }
}
