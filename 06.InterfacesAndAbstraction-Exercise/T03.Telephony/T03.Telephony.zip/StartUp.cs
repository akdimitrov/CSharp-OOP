﻿using System;
using T03.Telephony.Core;

namespace T03.Telephony
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
