﻿namespace T03.Telephony.Cotracts
{
    public interface ICallable
    {
        string Call(string phoneNumber);
    }
}
