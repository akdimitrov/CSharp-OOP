﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T05.BirthdayCelebrations.Contracts
{
    public interface IIdentifiable
    {
        string Id { get; set; }
    }
}
