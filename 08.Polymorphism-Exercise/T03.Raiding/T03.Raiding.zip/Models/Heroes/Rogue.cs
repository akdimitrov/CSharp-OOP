﻿namespace T03.Raiding.Models.Heroes
{
    public class Rogue : BaseFighter
    {
        public Rogue(string name) : base(name, 80) { }
    }
}
