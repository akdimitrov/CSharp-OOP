﻿namespace T03.Raiding.Models.Heroes
{
    public class Warrior : BaseFighter
    {
        public Warrior(string name) : base(name, 100) { }
    }
}
