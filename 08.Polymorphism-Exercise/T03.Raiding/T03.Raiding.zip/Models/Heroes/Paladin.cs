﻿namespace T03.Raiding.Models.Heroes
{
    public class Paladin : BaseHealer
    {
        public Paladin(string name) : base(name, 100) { }
    }
}
