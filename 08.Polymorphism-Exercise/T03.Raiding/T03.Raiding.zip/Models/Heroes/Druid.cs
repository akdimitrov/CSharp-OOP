﻿namespace T03.Raiding.Models.Heroes
{
    public class Druid : BaseHealer
    {
        public Druid(string name) : base(name, 80) { }
    }
}
