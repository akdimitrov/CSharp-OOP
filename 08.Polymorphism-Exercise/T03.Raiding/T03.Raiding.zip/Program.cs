﻿using T03.Raiding.Core;

namespace T03.Raiding
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
