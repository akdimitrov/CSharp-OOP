﻿using T02.VehiclesExtension.Core;

namespace T02.VehiclesExtension
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
