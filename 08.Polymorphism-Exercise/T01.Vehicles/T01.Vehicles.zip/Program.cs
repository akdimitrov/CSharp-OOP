﻿using T01.Vehicles.Core;

namespace T01.Vehicles
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
