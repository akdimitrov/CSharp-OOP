﻿namespace T04.WildFarm.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
