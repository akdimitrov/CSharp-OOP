﻿namespace T04.WildFarm.Contracts
{
    public interface IFeline : IMammal
    {
        string Breed { get; }
    }
}
