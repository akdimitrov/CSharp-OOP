﻿namespace T04.WildFarm.Contracts
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
