﻿namespace T04.WildFarm.Core
{
    public interface IEngine
    {
        void Run();
    }
}
