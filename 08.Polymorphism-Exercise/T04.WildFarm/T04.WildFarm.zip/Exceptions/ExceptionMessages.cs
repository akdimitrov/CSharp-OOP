﻿namespace T04.WildFarm.Exceptions
{
    public static class ExceptionMessages
    {
        public const string FoodNotPreffered = "{0} does not eat {1}!";
    }
}
