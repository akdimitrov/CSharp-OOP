﻿using T04.WildFarm.Core;

namespace T04.WildFarm
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
