﻿namespace T04.WildFarm.Models.Contracts
{
    public interface IFeline : IMammal
    {
        string Breed { get; }
    }
}
