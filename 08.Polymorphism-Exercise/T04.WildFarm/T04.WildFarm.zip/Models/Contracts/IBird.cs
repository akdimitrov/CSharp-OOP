﻿namespace T04.WildFarm.Models.Contracts
{
    public interface IBird : IAnimal
    {
        double WingSize { get; }
    }
}
